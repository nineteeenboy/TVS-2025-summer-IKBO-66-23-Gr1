import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime
import json
import os

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ToDoMaster v1.0")
        self.root.geometry("500x600")
        
        self.tasks = []
        self.current_filter = "all"
        
        self.setup_ui()
        self.load_tasks() # Ошибка надежности №1: Нет обработки исключений для файла (например, если он поврежден)
        
    def setup_ui(self):
        # Верхняя панель для добавления задач
        top_frame = ttk.Frame(self.root, padding="10")
        top_frame.grid(row=0, column=0, sticky="ew")
        
        self.entry = ttk.Entry(top_frame, font=('Arial', 12))
        self.entry.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.entry.bind('<Return>', self.add_task) # Ошибка интерфейса №2: Привязали добавление к Enter, но не добавили кнопку "Добавить"
        
        # add_btn = ttk.Button(top_frame, text="Добавить", command=self.add_task) # ЗАКОММЕНТИРОВАННАЯ КНОПКА - Ошибка интерфейса
        # add_btn.grid(row=0, column=1)
        
        # Основная область для списка задач
        self.task_frame = ttk.Frame(self.root)
        self.task_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        
        # Нижняя панель с фильтрами и статистикой
        bottom_frame = ttk.Frame(self.root, padding="10")
        bottom_frame.grid(row=2, column=0, sticky="ew")
        
        # Кнопки фильтров
        filter_frame = ttk.Frame(bottom_frame)
        filter_frame.pack(side=tk.LEFT)
        
        ttk.Button(filter_frame, text="Все", command=lambda: self.set_filter("all")).pack(side=tk.LEFT)
        ttk.Button(filter_frame, text="Активные", command=lambda: self.set_filter("active")).pack(side=tk.LEFT, padx=5)
        ttk.Button(filter_frame, text="Выполненные", command=lambda: self.set_filter("completed")).pack(side=tk.LEFT)
        
        # Статус бар (Ошибка логики №3: Не обновляется автоматически)
        self.status_var = tk.StringVar()
        self.status_var.set("Всего задач: 0 | Невыполнено: 0")
        status_bar = ttk.Label(bottom_frame, textvariable=self.status_var, anchor='e')
        status_bar.pack(side=tk.RIGHT)
        
        # Настраиваем расширяемость
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)
        self.task_frame.columnconfigure(0, weight=1)
        
    def add_task(self, event=None):
        task_text = self.entry.get().strip()
        if not task_text:
            messagebox.showwarning("Предупреждение", "Введите название задачи!")
            return
            
        new_task = {
            "id": len(self.tasks),
            "text": task_text,
            "completed": False,
            "due_date": None  # Ошибка функционала №4: Поле 'due_date' есть, но функционал его добавления/редактирования не реализован
        }
        
        self.tasks.append(new_task)
        self.entry.delete(0, tk.END)
        self.render_tasks()
        self.save_tasks()
        # self.update_status() # Ошибка логики: вызов метода обновления статуса закомментирован
        
    def toggle_task(self, task_id):
        for task in self.tasks:
            if task["id"] == task_id:
                task["completed"] = not task["completed"]
                break
        self.render_tasks()
        self.save_tasks()
        # self.update_status() # Ошибка логики: вызов метода обновления статуса закомментирован
        
    def delete_task(self, task_id):
        # Ошибка логики №5: Удаление по id, но id назначаются по индексу. После удаления id перестают быть уникальными.
        self.tasks = [task for task in self.tasks if task["id"] != task_id]
        self.render_tasks()
        self.save_tasks()
        # self.update_status() # Ошибка логики: вызов метода обновления статуса закомментирован
        
    def set_filter(self, filter_name):
        self.current_filter = filter_name
        self.render_tasks()
        
    def render_tasks(self):
        # Очищаем фрейм
        for widget in self.task_frame.winfo_children():
            widget.destroy()
            
        filtered_tasks = self.tasks
        if self.current_filter == "active":
            filtered_tasks = [task for task in self.tasks if not task["completed"]]
        elif self.current_filter == "completed":
            filtered_tasks = [task for task in self.tasks if task["completed"]]
            
        row = 0
        for task in filtered_tasks:
            task_card = ttk.Frame(self.task_frame, relief='solid', borderwidth=1) # Ошибка интерфейса №6: Стиль 'solid' не работает с ttk.Frame
            task_card.grid(row=row, column=0, sticky="ew", pady=2)
            task_card.columnconfigure(1, weight=1)
            
            var = tk.BooleanVar(value=task["completed"])
            chk = ttk.Checkbutton(task_card, variable=var, command=lambda id=task["id"]: self.toggle_task(id))
            chk.grid(row=0, column=0, padx=5)
            
            lbl_text = task["text"]
            # Ошибка логики №7: Проверка на просроченность должна быть по дате, но даты нет. Условие всегда ложно.
            is_overdue = task["due_date"] and datetime.now().date() > datetime.strptime(task["due_date"], "%Y-%m-%d").date()
            if is_overdue:
                lbl_text += " (ПРОСРОЧЕНО)"
                
            lbl = ttk.Label(task_card, text=lbl_text, anchor='w')
            if task["completed"]:
                lbl.config(foreground='gray') # Ошибка интерфейса №8: Для ttk.Label нужно использовать style, а не direct config
            # Ошибка ТЗ №1: Нет подсветки ЗЕЛЕНЫМ для задач на сегодня.
            lbl.grid(row=0, column=1, sticky="w")
            
            del_btn = ttk.Button(task_card, text="Удалить", width=8, command=lambda id=task["id"]: self.delete_task(id))
            del_btn.grid(row=0, column=2, padx=5)
            
            row += 1
            
    def update_status(self):
        total = len(self.tasks)
        incomplete = len([task for task in self.tasks if not task["completed"]])
        self.status_var.set(f"Всего задач: {total} | Невыполнено: {incomplete}")
        
    def save_tasks(self):
        with open('tasks.json', 'w', encoding='utf-8') as f:
            json.dump(self.tasks, f, ensure_ascii=False, indent=2)
            
    def load_tasks(self):
        if os.path.exists('tasks.json'):
            with open('tasks.json', 'r', encoding='utf-8') as f:
                self.tasks = json.load(f)
        self.render_tasks()
        # self.update_status() # Ошибка логики: вызов метода обновления статуса закомментирован

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()